# EmotioNet
Demo Code for "EmotioNet: A 3-D Convolutional Neural Network for EEG-based Emotion Recognition"<br />
The code is based on braindecode: https://robintibor.github.io/braindecode/
